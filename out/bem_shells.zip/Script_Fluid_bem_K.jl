# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#	
#	Script fluid sphere. Backscattering versus frequency
#	
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# v. 14/8/20




	# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	# Mesh sphere radius R
	meshSphereR = "meshes/Esfera_007_2450.stl" ; 

	println("Mesh : ")
	normales, selv, vertex = GetMesh_fast( meshSphereR ) ;
	
	# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 	# Frecuencias a calcular
	f_0 = 10 ; # Frecuencias en Hz
	f_1 = 38000 ;
	N = 10 ; # Cantidad de frecuencias
	FrecArray = collect( Linspace( log10(f_0), log10(f_1), N ) ) ; # Array de números de onda
	FrecArray = 10 .^(FrecArray) ;
	# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	# Parámetros de los dos medios
	c0 = 1477.4 ;
	c1 = 0.23 * c0 ;
	rho0 = 1026.8 ;
	rho1 = 0.00129 * rho0 ;

	# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	kinc = [ -1.0, 0, 0 ] ; # Incidence direction (normalized to unity)

	# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	# Distributing all the structures to all the cores
	for i in cores
		SendToProc( i, selv = selv, vertex = vertex, normales = normales, 
			kinc = kinc, rho0 = rho0, rho1 = rho1 ) ;
	end
	
	if false
		include("../../julia/JUL.SpheresFluid.jl") ;
		sum_size = 60 ;
		R = 0.07 ;
		rho10 = rho1 / rho0 ;
		FinfSphere = Finf_LiquidSphere( rho10, c0, c1, R, sum_size, f_0, f_1, 25 ) ;
		writedlm( "out/fluid_sphere_exact_k.dat", [ FinfSphere[:,1]  TS.( FinfSphere[:,4] ) ] ) ;
	end

	# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	# Calculating the far field in parallel  
# 	finf = bem_shell_farfield_bs_K( FrecArray, kinc, c0, c1, c2, rho0, rho1, rho2,
# 			selv1, vertex1, normales1, selv2, vertex2, normales2, cores ) ;
	TypeNumber = ComplexF64 ; # Tipo de números para las matrices
	finf = bem_fluid_farfield_bs_K( FrecArray, kinc, c0, c1, rho0, rho1, 
			selv, vertex, normales, cores, TypeNumber )

	# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	# Saving TS to disk
	writedlm( "out/fluid_bem_sphere_k.dat", [ FrecArray  TS.( finf ) ] ) ;

	@everywhere GC.gc() ;
	
