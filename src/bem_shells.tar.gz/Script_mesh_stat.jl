# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#	
#	Script fluid vejiga. Estadística de meshes
#	
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# v. 15/8/20


	# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	# Mesh sphere radius R
	meshBladder = "meshes/Fish_vejiga_smooth.stl" ; 
	meshBladder = "meshes/Vejiga_11cm.stl" ; 

	println("Mesh : ")
	normales, selv, vertex = GetMesh_fast( meshBladder ) ;
	
# 	vertex = vertex .* 1e-3 ;

	include("JUL.meshes_stats.jl") ;


	# Vector de vértices
#	vertex_vector = [ vertex[i,:] for i = 1 : size(vertex)[1] ] ;
	
	# Lista de segmentos
	Segm = EdgesStat( selv, vertex ) ;

	# Cálculo de histograma correspondiente
# 	datas, bines = histograma_datos( Segm, 200 ) ;
	datas, bines = histog_datos( Segm, 300 ) ;

	# Salvo a disco el histograma de longitudes de segmentos
	writedlm( "out/histograma.dat", [ bines datas ] ) ;


	
	# El umbral es la longitud de segmento máxima permitida
	long_umbral = 0.001788
	binMax = findfirst( x -> x >= long_umbral, bines ) ;
	if binMax == nothing
		println("100 % cumple.")
	else
		porcentaje =  sum( datas[1:binMax] ) / sum( datas[1:end] ) ;
		println("Dado el umbral : ", long_umbral, " por debajo está un: ", porcentaje, " '%' de la mesh") ;
	end
	
	Toler = 0.95 ;
	
	Suma = 0.0 ;
	for i = 1 : size( datas )[1]
		Suma = sum( datas[1:i] ) / sum( datas[1:end] ) ;
		if Suma <= 0.95
			;
		else
			println( "Se cumple la tolerancia para una longitud: ", bines[i], "en i =", i );
			return ;
		end
	end
		
		
