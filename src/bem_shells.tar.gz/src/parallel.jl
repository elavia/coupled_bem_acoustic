

	# Rutinas genéricas para trabajo en paralelo bajo Julia 

	# v. 15-3-2019
	
	# Adaptado para Julia 1.1
	# Incorporado código básico de JUL.parallel.jl
	
	# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	# 	INDICE
	# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	
	# 1. Rutinas primitivas de trabajo en paralelo
	#			CargarProcesadores( args... )
	#			SendToProc( p::Int ; args... )
	#			GetFromProc( p::Int, nm::Symbol ; mod=Main )
	# 2. Rutinas de alto nivel (manipulación de entes generales)
	#			ConvertirSharedArray( arreglo, proc_id )
    

	using Distributed
	# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	#	1. Rutinas primitivas de trabajo en paralelo

	# Función para cargar procesadores en un dado servidor
	# Sintaxis:			"servidor1", cores1, "servidor2", cores2, ...
	# Output:			'Cores' : vector con el id de los procesadores
	function CargarProcesadores( args... )
		Size = length( args ) ; # Cantidad de argumentos
		if mod( Size, 2 ) != 0
			println("Error : Número equivocado de argumentos") ;
			return ;
		end
		# Si la cantidad de argumentos es correcta
		Cores = Array{ Int64 }( undef, 0 ) ;
		for i in collect( 1 : 2 : Size )
			proces = addprocs( [ ( args[ i ], args[ i + 1 ] ) ] ) ;
			Cores = [ Cores ; proces ] ;
			println( "En '", args[i], "' se cargaron ",args[i+1], " procesadores" ) ;
		end
		return Cores
	end
    
	# Función que efectúa localmente una relación del tipo 'nm = val' dada en 'args' y manda a 
	# un proceso 'p' la variable 'nm'
	function SendToProc( p::Int ; args... )
	    for ( nm, val ) in args
		@spawnat( p, Core.eval( Main, Expr( :(=), nm, val) ) ) ;
	    end
	end

	# Función que trae desde el proceso 'p' un ente 'nm' (se lo introduce como ':nm')
	function GetFromProc( p::Int, nm::Symbol ; mod=Main )
		fetch( @spawnat( p, getfield( mod, nm ) ) ) ;
	end


	# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	#	2. Rutinas de alto nivel (manipulación de entes generales)

	# Función para convertir un 'arreglo' en un SharedArray compartido por los nodos dados
	# por los pids 'proc_id'.
	# Sucedió que utilizando SharedArrays en conjunción con DistributedArrays la rutina
	# 	'convert( Array, <arreglo> )'
	# no funcionaba (8-2018) (posible bug? o misinterpretation?).
	# Soporta vectores y matrices ahora (2-2019)
	function ConvertirSharedArray( arreglo, proc_id )
		arreglo_sh = SharedArray{typeof(arreglo[1])}( size(arreglo), pids = proc_id ) ;
		if ndims( arreglo ) == 1
			for i = 1 : size(arreglo)[1]
				arreglo_sh[i] = arreglo[i] ;
			end
			return arreglo_sh
		elseif ndims( arreglo ) == 2
			for i = 1 : size(arreglo)[1]
				for j = 1 : size(arreglo)[2]
					arreglo_sh[i,j] = arreglo[i,j] ;
				end
			end
			return arreglo_sh
		else
			println("Array no soportado") ;
		end
	end
