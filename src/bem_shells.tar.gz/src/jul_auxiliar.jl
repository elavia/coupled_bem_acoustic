# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#	
#	Julia auxiliary routines
#	
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# v. 16/8/20

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Index:

# 	SinC( x )
#	TS( finf::Number )
#	Linspace( Start::Number, Stop::Number, Size::Number )
#	BuildAngulosK( theta, phi ; matriz = false )
#	GetKinc( angulos::Tuple )
#	SaveMatrix( M, GridX, GridY, file::String )
# 	BiG( numero::Real )
# 	BiG( numero::Complex )
# 	BiG( numero::Irrational )
# 	BiG( numero::Complex{Bool} )
# 	BiG( numero::String )

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	
	function SinC( x )
		return sinc( x/pi ) ;
	end
	
	# Función para calcular el 'TS' a partir de un patrón de campo lejano 'finf' 
	function TS( finf::Number )
		return 20 * log10( abs( finf ) ) ;
	end
	
	function Linspace( Start::Number, Stop::Number, Size::Number )
		return range( Start, stop=Stop, length=Size )
	end
	
	# Función que construye grilla de ángulos y versores de incidencia 3D para ciertos ('theta','phi')
	# donde uno de ambos ángulos esféricos es una constante (un escalar) y el otro una tupla del tipo
	# ('N', 'ang_0', 'ang_1') que se usa para construir la grilla correspondiente.
	# Las incidencias son las esféricas :
	#           [ sin(th)cos(ph)   sin(th)sin(ph)   cos(th) ]
	# Se fija un plano en la esfera de incidencias ( 'theta' o 'phi' cte. ) y luego se discretiza
	# en un grid a lo largo de ese ángulo.
	# La salida es un vector 'R' de ángulos y un array 'Q' conteniendo versores de incidencia 3D 
    	# que puede ser una matriz o un vector de vectores.
	# Se proveen dos tipos de salidas para el vector de direcciones 'Q' : 
	#	N-element Array{Array{Float64,1}, 1}	(default con dos argumentos: matriz=false)
	#	Nx3 Array{Float64,2}			matriz=true
	function BuildAngulosK( theta, phi ; matriz = false )
		if size( theta, 1 ) > 1 # theta es el array
			R = collect( Linspace( theta[2], theta[3], theta[1] ) ) ; # Grilla de ángulos
			Q = GetKinc.( [ tuple( R[i], phi ) for i = 1 : size(R)[1] ] ) ;
			if matriz # Si estuvo matriz=true entonces hago un reshape
				return R, vcat(transpose(Q)...)
			else
				return R, Q
			end
		else # phi es el array
			if ( phi[2] == pi || phi[3] == pi ) # Por si es irracional (13-3-2019)
				phi = 1 .* phi ;
			end
			R = collect( Linspace( phi[2], phi[3], phi[1] ) ) ; # Grilla de ángulos
			Q = GetKinc.( [ tuple( theta, R[i] ) for i = 1 : size(R)[1] ] ) ;
			if matriz # Si estuvo matriz=true entonces hago un reshape
				return R, vcat(transpose(Q)...)
			else
				return R, Q
			end
		end
	end
	
	# GetKinc --> Vector de incidencia (k_x,k_y,k_z) desde (\theta,\phi)
	# Versión mejorada 15-3-2019
	# Función que calcula una dirección en función de dos ángulos de esféricas
	# dados por la tupla angulos=(theta,phi).
	# Funciona para  0 <= theta <= pi  ||   0 <= phi <= 2*pi,    o bien
	# 				 0 <= theta <= 2*pi  ||   0 <= phi <= pi
	function GetKinc( angulos::Tuple )
		theta = angulos[1] ;
		phi = angulos[2] ;
		if phi == 0 # Sobre el eje x
			cphi = 1.0 ;
			sphi = 0 ;
		elseif phi == pi/2 # Sobre el eje y
			cphi = 0 ;
			sphi = 1.0 ;
		elseif phi == pi || phi == 1*pi # Sobre el eje x
			cphi = -1.0 ;
			sphi = 0 ;
		elseif phi == 3*pi/2 # Sobre el eje y
			cphi = 0 ;
			sphi = -1.0 ;
		elseif phi == 2*pi # Sobre el eje x
			cphi = 1.0 ;
			sphi = 0 ;
		else # Genérico
			cphi = cos( phi ) ;
			sphi = sin( phi ) ;
		end
		if theta == 0
			cth = 1.0 ;
			sth = 0 ;	
		elseif theta == pi/2
			cth = 0 ;
			sth = 1.0 ;
		elseif theta == pi || theta == 1*pi 
			cth = -1.0 ;
			sth = 0 ;
		elseif theta == 2*pi
			cth = 1.0 ;
			sth = 0 ;
		else # Genérico
			cth = cos( theta ) ;
			sth = sin( theta ) ;
		end
		return [ cphi * sth, sphi * sth, cth ] ;
	end
	
	# Salva lista de elementos M_ij de una matriz que correspondes a grids X_j e Y_j 
	# de acuerdo con la equivalencia M_ij para 'i' recorriendo Y y j recorriendo X.
	# Entonces : Size = Tam Col 'M' es la cantidad de valores en X (size GridX)
	# y entonces : Size = Tam Filas 'M' es la cantidad de valores en Y (size GridY).
	# Entonces, se guarda :
	#	X	Y	M( Y, X )
	# donde el primer índice de la matriz es Y y el segundo es X.
	function SaveMatrix( M, GridX, GridY, file::String )
		output = open( file, "w" ) ; # Apertura de archivo
		S = size( M ) ;
		for i = 1 :  S[1] # Filas
			for j = 1 : S[2] # Columnas
				writedlm( output, [ GridX[j] GridY[i] M[i,j] ] ) ;
			end
		end
		close( output ) ; # Cierre de archivo
	end
	
	# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 
	# Arbitrary Precision Routines
	
	# Diferentes métodos para convertir un número a Bigfloat tomando correctamente decimales
	# Para literales conviene big"nro", que evita la conversión previa a string
	function BiG( numero::Real )
		parse( BigFloat,"$(numero)" );
	end
	function BiG( numero::Complex )
		parse(BigFloat,"$(real(numero))") + im*parse(BigFloat,"$(imag(numero))") ;
	end
	# Aparentemente (para pi, e funciona) la implementación "big" lo convierte del modo correcto
	function BiG( numero::Irrational ) # Para entradas como pi, e
		big( numero ) ; # BiG( 1.0 )*numero ;
	end
	function BiG( numero::Complex{Bool} ) # Para entradas como im
		big"1" * numero ;
	end 
	function BiG( numero::String ) # Cuando mandamos un 'string' para no perder las cifras 
	# en la conversión.
		parse( BigFloat, numero );
	end	
	# Por comprehension
	BiG( numero::AbstractArray ) = [ BiG( n ) for n in numero ] ;
	BiG( numero::Tuple ) = [ BiG( n ) for n in numero ] ;
