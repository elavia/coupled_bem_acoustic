# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# 	Código de cálculos auxiliares y estadísticos sobre meshes 
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# v. 18/8/2020 mínimamente adaptado a Julia 1.0

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# v. 18-1-2019
# Este código es genérico para meshes (de tal forma es útil en cualquier implementación que las use)

# Si la mesh es monstruosa, las estructuras 'selv' y 'vertex' son demasiado time consuming de modo que 
# resulta mucho más conveniente utilizar la matriz 'MP'. Por ello se desarrolla código para ese tipo
# de entradas también.

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#	Rutinas para realizar medidas estadísticas sobre meshes de triángulos 
#

	# Tomamos la estructura 'selv' que tiene los vértices de cada triángulo cuyas coordenadas están en 'vertex'.
	# Retorna lista de longitudes de edge no repetidos (i.e. no provenientes de un mismo par de vértices)
	# Los 3-tupla  ( longEdge, id_verticeA, id_verticeB ) una vez ordenados los vértices por número identifican
	# unívocamente al segmento. Si hay muchos segmentos de igual 'longEdge' (más de dos) no tendrán iguales
	# id's.

	function EdgesStat( selv, vertex )
		Size_Filas = size( selv )[1] ;
		# Primeramente ordenar por número de vértice: [ V1 V2 V3 ] con V1 < V2 < V3
		selv_sorted = Array{Int64}( undef, Size_Filas, 3 ) ;
		for i = 1 : Size_Filas
			selv_sorted[ i , : ] = sort( selv[ i, : ] ) ;
		end
		# Armo un arreglo de:  V_A  V_B  long_edge
		Arreglo = Array{Array{Float64,2}}( undef, 0 ) ; 
		for i = 1 : Size_Filas
			V1 = vertex[ selv_sorted[ i, 1 ], : ] ; # Vértice 1
			V2 = vertex[ selv_sorted[ i, 2 ], : ] ; # Vértice 2
			V3 = vertex[ selv_sorted[ i, 3 ], : ] ; # Vértice 3
			push!( Arreglo, hcat( norm( V1 - V2 ), selv_sorted[i,1], selv_sorted[i,2] ) ) ;
			push!( Arreglo, hcat( norm( V1 - V3 ), selv_sorted[i,1], selv_sorted[i,3] ) ) ;
			push!( Arreglo, hcat( norm( V2 - V3 ), selv_sorted[i,2], selv_sorted[i,3] ) ) ;
		end
		Edges_clean = Array{ Float64 }( undef, 0 ) ; # Lista vacía de segmentos 'clean'
		# epsil = 0 ; #1E-12 ; # Hardcoded precision (se puede usar 0 pues vienen del mismo parseo)
		# WARNING: copié la solución para reemplazar sortrows. Supongo que está bien
		Edges = sortslices( vcat( Arreglo... ), dims=1 ) ; # Transformación a matriz y orden por la long. de edge 
		push!( Edges_clean, Edges[1] ) ; # El primero entra siempre
		for i = 2 : size( Edges )[1] # Recorro la lista
			if norm( Edges[i,:] - Edges[i-1,:] ) == 0 # Si fue = al anterior es repetido. No entra
				; # Ya está en la lista
			else # Si no fue igual al anterior es la primera (tal vez única) ocurrencia. Entra
				push!( Edges_clean, Edges[i] ) ;
			end
		end
		return Edges_clean
	end
	
	# Función que devuelve lista de segmentos del mesh dado éste en formato 'MP' (sin repetidos) 
	function EdgesStat( MP )
		N = size( MP )[2] ; # Nro de triángulos
		# Armo un arreglo de:  V_A  V_B  long_edge
		Arreglo = Array{Array{Float64,1}}( undef, 0 ) ;
		for i = 1 : N
			V1 = MP[ 1:3, i ] ; # Vértice 1
			V2 = MP[ 4:6, i ] ; # Vértice 2
			V3 = MP[ 7:9, i ] ; # Vértice 3
			Vfirst, Vsecond = OrdenarRestaVertices( V1, V2 ) ;
			push!( Arreglo, [ norm( V1 - V2 ) ; Vfirst ; Vsecond ] ) ;
			Vfirst, Vsecond = OrdenarRestaVertices( V1, V3 ) ;
			push!( Arreglo, [ norm( V1 - V3 ) ; Vfirst ; Vsecond ] ) ;
			Vfirst, Vsecond = OrdenarRestaVertices( V2, V3 ) ;
			push!( Arreglo, [ norm( V2 - V3 ) ; Vfirst ; Vsecond ] ) ;
		end
		Edges_clean = Array{ Float64 }( undef, 0 ) ; # Lista vacía de segmentos 'clean'
#		epsil = 1E-14 ; # Hardcoded precision (podríamos poner 0 puesto que provienen del mismo parseo)
		Edges = sortrows( hcat( Arreglo... )' ) ; # Transformación a matriz y orden por long edge
		push!( Edges_clean, Edges[1] ) ; # El primero entra siempre
		# El criterio para saber si ya se ha contabilizado el segmento Va - Vb y no duplicarlo con Vb - Va
		# es más complicado porque los triángulos no tienen id numérico unívoco (estructura 'selv').
		# Además puede darse el caso de que existan 
		for i = 2 : size( Edges )[1] # Recorro la lista
#			HayVerticesRepetidos( Edges[i,:], Edges[i-1,:], Edges_clean ) ;
			if norm( Edges[i,:] - Edges[i-1,:] ) == 0 # Si fue = al anterior es repetido. No entra
				; # Ya está en la lista
			else # Si no fue igual al anterior es la primera (tal vez única) ocurrencia. Entra
				push!( Edges_clean, Edges[i] ) ;
			end
		end
		return Edges_clean
	end

	# Función que devuelve los dos vértieces Va Vb ordenados de acuerdo con que su resta Va - Vb
	# tenga mayor cantidad de entradas positivas o nulas que negativas.
	# Así los segmentos |Va - Vb| y |Vb - Va| tendrán asociados un único par ordenado de vértices 
	#	(Va, Vb) : si hubo mayor cantidad de entradas positivas en Va-Vb 
	# 	(Vb, Va) : en el otro caso
	function OrdenarRestaVertices( Va, Vb  )
		NroPosDirecto = size( find( ( Va - Vb ) .> 0 ) )[ 1 ] ; # Número de los positivos
		NroPosInvertido = size( find( ( Vb - Va ) .> 0 ) )[ 1 ] ; # Número de los positivos
		if NroPosDirecto > NroPosInvertido # (2,3)
			return Va, Vb
		elseif NroPosDirecto < NroPosInvertido
			return Vb, Va
		else # Si hubo igual cantidad (hay un cero)
			nonulos = find( ( Va - Vb ) .!= 0 )
			# Tomo el primero de los nonulos
			if Va[nonulos[1]] > Vb[nonulos[2]]
				return Va, Vb
			else
				return Vb, Va
			end
		end	
	end

#	S = size( Edges )[1]
#	nro_edges = 0 ;
#	LongEdgeActual = Edges[1,1] ; # El primero
#	i = 1 # Inicial
#	while i <= S
#		Edges[i,1] == LongEdgeActual ;
#		while Edges[ i, 1 ] == LongEdgeActual
#			nro_edges += 1 ;
#			i += 1 ;
#		end
#		i es el primero que no es 
#	end


#	GetCuadrante( Vector )
#		if Vx > 0 # 1,4, 5,8
#			if Vy > 0  # 1,5
#				if Vz > 0  # 1
#					return 1
#				elseif Vz < 0

#				else # Vz == 0
#					return 
#				end

#		if Vz > 0

#		elseif Vz < 0

#		else # Vz == 0
#			
#		end	

#	julia> EdgesNew[6095:6098,:]
#	4×7 Array{Float64,2}:
# 	0.249226  4.59242e-16  -1.12482e-31  -62.0     0.246947     -6.04847e-17  -61.9664
# 	0.249226  4.59242e-16  -1.12482e-31   62.0     0.246947     -6.04847e-17   61.9664
# 	0.249226  0.246947     -6.04847e-17  -61.9664  4.59242e-16  -1.12482e-31  -62.0   
# 	0.249226  0.246947     -6.04847e-17   61.9664  4.59242e-16  -1.12482e-31   62.0  

#el ordenamiento es crucial, como se ve acá. Si comparo con el inmediato anterior (2 con 1 y 4 con 3) entran los cuatro vértices
#y en realidad son idénticos 1 y 3 y 2 y 4 (debieran entrar solo dos).

	# Ingresan dos filas   | longEdge | Vax Vay Vaz | Vbx Vby Vbz |  
	function HayVerticesRepetidos( FilaActual, FilaAnterior, EdgesClean )
		# Si están los vértices ordenados igual o shifteados se considera que es el mismo segmento
#		if ( norm( FilaActual - FilaAnterior ) == 0 || 
#			norm( FilaActual - [ FilaAnterior[1] ; FilaAnterior[5:7] ; FilaAnterior[2:4] ] ) == 0 )
#			;
#		else
#			push!( EdgesClean, FilaActual[1] ) ;
#		end
		if ( FilaActual == FilaAnterior || 
			FilaActual == [ FilaAnterior[1] ; FilaAnterior[5:7] ; FilaAnterior[2:4] ]  )
			;
		else
			push!( EdgesClean, FilaActual[1] ) ;
		end
	end

	function DescartarTriangulos( selv, vertex, z_cut )
		Size_Filas = size( selv )[1] ;
		Idx = Array{Int64}( undef, 0 ) ;
		for i = 1 : Size_Filas
			if minimum( abs.(vertex[selv[i,:],3]) ) > z_cut
				push!( Idx, i );
			end
		end
		return Idx
	end

	# Función que retorna un vector 'Segmentos' conteniendo longitudes R de segmentos internos de triángulos según
	# la regla de cuadratura 'QuadRule' usada para un centroide de triángulo 'P' y otro 'Q'
	function Segmentos_internos_triangulos( P::Array, QA::Array, QB::Array, QC::Array, Lponel::Bool, QuadRule::Array )
		# WARNING : La QuadRule cambiará según Lponel. Esto debe asegurarse desde fuera	
		Segmentos = Array{ Float64 }( undef, 0 ) ; # Defino un array vacío
		QBMQA = QB - QA ; # 
		QCMQA = QC - QA ; # 
		QCMQB = QC - QB ; # 
		if Lponel # 
			for q = 1 : size( QuadRule )[1]
				Q = [ QA[ 1 ] + QuadRule[ q, 1 ] * QBMQA[ 1 ] + QuadRule[ q, 2 ] * QCMQA[ 1 ],
					QA[ 2 ] + QuadRule[ q, 1 ] * QBMQA[ 2 ] + QuadRule[ q, 2 ] * QCMQA[ 2 ],
					QA[ 3 ] + QuadRule[ q, 1 ] * QBMQA[ 3 ] + QuadRule[ q, 2 ] * QCMQA[ 3 ] ] ;
				R = norm( P - Q ) ;

			end
		else # "No Lponel"
			for q = 1 : size( QuadRule )[1]
				Q = [   QA[ 1 ] + QuadRule[ q, 1 ] * QBMQA[ 1 ] + QuadRule[ q, 2 ] * QCMQA[ 1 ],
					QA[ 2 ] + QuadRule[ q, 1 ] * QBMQA[ 2 ] + QuadRule[ q, 2 ] * QCMQA[ 2 ],
					QA[ 3 ] + QuadRule[ q, 1 ] * QBMQA[ 3 ] + QuadRule[ q, 2 ] * QCMQA[ 3 ] ] ;
				R = norm( P - Q ) ;
				push!( Segmentos, R ) ;
			end
		end
		return  Segmentos ;
	end

	function Longitudes_segmentos_internos( selv, vertex, filaI )
		# Constantes y parámetros
		Segmentos = Array{ Float64 }( undef, 0 ) ;
		NSE = size(selv)[1] ;
#		Nj = normales[j,:] ;
		# Reglas de cuadratura
		WQOFF,XQOFF,YQOFF = cquts8( ) ; # glt7x3(a,b,c) ;# 
		WQON, XQON, YQON = cqutm9( ) ; # glt7x3(a,b,c) ; # 
		QuadRuleOff = [ XQOFF YQOFF WQOFF] ;
		QuadRuleOn = [ XQON YQON WQON ] ;
#		for i = 1 : NSE
		for i = filaI
			PA = vertex[ selv[ i, 1 ], 1:3 ] ; 
			PB = vertex[ selv[ i, 2 ], 1:3 ] ;
			PC = vertex[ selv[ i, 3 ], 1:3 ] ;
			P = ( PA + PB + PC ) / 3 ; 
#			Ni = normales[i,:] ;
#			Ni = normal3(PA,PB,PC) ;
			for j = 1 : NSE
				QA = vertex[ selv[ j, 1 ], 1:3 ] ;
				QB = vertex[ selv[ j, 2 ], 1:3 ] ;
				QC = vertex[ selv[ j, 3 ], 1:3 ] ;
				if j == i
					map( x -> push!( Segmentos, x ), Segmentos_internos_triangulos( P, QA, QB, QC, true, QuadRuleOn ) ) ;
				else
					map( x -> push!( Segmentos, x ), Segmentos_internos_triangulos( P, QA, QB, QC, false, QuadRuleOff ) ) ;	
				end
			end
		end
		return Segmentos
	end

	# Función que toma un vector de datos 'data' y fabrica un histograma de ocurrencias en 'nbins'
	function histograma_datos(data, nbins)
		min = minimum( data ) ;
		max = maximum( data ) ;
		N = length(data)             # How many elements in the input vector 'data' ?
  		delta = (max-min)/nbins      # Bin size is inferred here from the maximal, minimal, and bin number
		out = zeros(nbins)           # Let's initialize the output data structures for the bin count
		bin = zeros(nbins)           # and for the bin centres...
		
		start = min                  # Left edge
		for k=1:nbins
			stop   = start + delta   # Right edge
# 			out[k] = length( find((data .>= start) .& (data .< stop)) ) # Count how many elements are between left and right 
			out[k] = length( filter( x -> ( x >= start) & ( x < stop) , data ) ) # Count how many elements are between left and right 
			bin[k] = start + delta/2. # Centre of the bin
			start  = stop            # New left edge
		end
		return out, bin
	end

	# Nueva versión de la función histograma (basada en lo que se hizo para cosmología 2018)
	# La anterior está basada en sumar 'delta' y hallé errores en esa implementación para algunos
	# valores racionales de 'delta'.
	function histog_datos( data, nbins )
		mini = minimum( data ) ;
		maxi = maximum( data ) ;
		N = length( data ) ; # Cantidad de elementos total
		vv = collect( Linspace( mini, maxi, nbins + 1 ) ) ; # Este vector tiene nbins+1
		# Esta conversión log10 y 10^ no es precisa y puede traer problemas
		vv[1] = mini ;
		vv[end] = maxi ;
		out = zeros( nbins )           # Let's initialize the output data structures for the bin count
		bin = zeros( nbins )           # and for the bin centres...
		for k = 1 : nbins
			inicial = vv[ k ]  # Borde izquierdo
			stop   = vv[ k + 1 ]   # Borde derecho
			if k != nbins # Cuántos elementos hay en el intervalo [,) 
# 				out[k] = length( find((data .>= inicial) .& (data .< stop)) ) 
				out[k] = length( filter( x -> ( x >= inicial) & ( x < stop), data  )  ) 
			else
# 				out[k] = length( find((data .>= inicial) .& (data .<= stop)) )
				out[k] = length( filter( x -> ( x >= inicial) & ( x <= stop), data ) ) 
			end	
			bin[k] = ( inicial + stop )/ 2  # Centro del bin
		end
		println("ocurr. hist. total | data total : ", sum( out ), " | ", N ) ;
		return out, bin
	end

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
