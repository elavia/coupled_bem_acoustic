# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#	
#	Script fluid vejiga. Backscattering versus frequency (segmento angular)
#	
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# v. 16/8/20

	# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	# Mesh sphere radius R
	meshBladder = "meshes/Fish_vejiga_smooth.stl" ; 

	println("Mesh : ")
	normales, selv, vertex = GetMesh_fast( meshBladder ) ;
	
# 	vertex = vertex ./ 20 ; # Esfera de radio 5 cm
	
	# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 	# Frecuencias a calcular
	f_0 = 37000 ; # Frecuencias en Hz
	f_1 = 39000 ;
	N = 60 ; # Cantidad de frecuencias
	FrecArray = collect( Linspace( (f_0), (f_1), N ) ) ; # Array de números de onda
# 	FrecArray = 10 .^(FrecArray) ;


	F = 1000 ; # Todo "en milímetros" (1000) o "metros" (1)
	# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	# Parámetros de los dos medios
	c0 = 1477.4 * F ;
	c1 = 0.23 * c0 ;
	rho0 = 1026.8 ;
	rho1 = 0.00129 * rho0 ;

	# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# 	kinc = [ -1.0, 0, 0 ] ; # Incidence direction (normalized to unity)
	# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 	# Semiplano de direcciones a calcular
	Nang = 100 ;
	theta = ( Nang, 70*pi/180, 110*pi/180 ) ; # ;
	phi = 0 ; #	phi = ( N, pi/2, 0 ) ;
	Angulos, pext = BuildAngulosK( theta, phi ; matriz = true ) ;

	# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	# Distributing all the structures to all the cores
	for i in cores
		SendToProc( i, selv = selv, vertex = vertex, normales = normales, pext = pext ) ;
	end

	# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	# Calculating the far field in parallel  
	TypeNumber = ComplexF64 ; # Tipo de números para las matrices
	Finf = bem_fluid_farfield_bs_K_pattern( FrecArray, pext, c0, c1, rho0, rho1, 
			selv, vertex, normales, cores, TypeNumber )

	# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	# Saving TS to disk
# 	writedlm( "out/fluid_bem_vejiga_k.dat", [ FrecArray  TS.( finf / F ) ] ) ;

	SaveMatrix( TS.( Finf / F ), FrecArray, Angulos*180/pi, "out/fluid_bem_vejiga_k_pattern.dat" ) ;

	@everywhere GC.gc() ;
	
